import { Component} from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {
  private name:string;
 private  course:string;
  constructor() {
    this.name="Meena";
    this.course="Java Full Stack";
   }

}
