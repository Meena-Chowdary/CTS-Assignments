import { VerbalPipe } from './verbal.pipe';

describe('VerbalPipe', () => {
  it('create an instance', () => {
    const pipe = new VerbalPipe();
    expect(pipe).toBeTruthy();
  });
});
