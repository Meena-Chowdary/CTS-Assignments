import { Component} from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent{
  mart:string;
  welcomeText:string;
  offer:string;
  
  constructor() { 
    this.mart="E-Mart";
    this.welcomeText="Welcome to E-Mart!! Shop as much as you want";
    this.offer="Offer season is ON!!"
  }

}
