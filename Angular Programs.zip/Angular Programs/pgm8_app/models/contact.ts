export class Contact {
    public contactId:number;
    public firstName:string;
    public lastName:string;
    public mobileNumber:string;
    public alternateMobileNumber:string;
    public mailId:string;
    public organization:string;
    public dob:Date;
}
