import { Injectable } from '@angular/core';
import {Contact} from '../models/contact';
@Injectable({
  providedIn: 'root'
})
export class ContactService {
  contacts:Contact[]; 
  constructor() {
    this.contacts=[
    {contactId:101,firstName:"Meena",lastName:"Chowdary",dob:new Date("1998-03-26"),mobileNumber:"9010930878",alternateMobileNumber:"9087654321",mailId:"meenachowdary@yahoo.com",organization:"cognizant"},
    {contactId:102,firstName:"Soumya",lastName:"Gadeshetti",dob:new Date("1997-08-18"),mobileNumber:"9087654321",alternateMobileNumber:"9010930878",mailId:"soumyagadeshetti@gmail.com",organization:"cognizant"},
    {contactId:103,firstName:"Vani",lastName:"Gundarapu",dob:new Date("1997-02-18"),mobileNumber:"7278997651",alternateMobileNumber:"8108765778",mailId:"vani@gmail.com",organization:"cognizant"}
    ];
   }

   getAll():Contact[]{
     return this.contacts;
   }

   get(Id:number){
     return this.contacts.find((c)=>(c.contactId==Id));
   }

   add(contact:Contact){
     this.contacts.push(contact);
   }

   update(contactId:Contact){
     let index=this.contacts.findIndex((c)=>(c.contactId===contactId.contactId));
     if(index>-1){
       this.contacts[index]=contactId;
     }
   }

   delete(Id:number){
     let index=this.contacts.findIndex((contact)=>(contact.contactId==Id));
     if(index>-1){
       this.contacts.splice(index,1);
     }
   }
}
