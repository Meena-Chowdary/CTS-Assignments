export class Task {
    public taskId:number;
    public taskName:string;
    public startDate:Date;
    public endDate:Date;
}

