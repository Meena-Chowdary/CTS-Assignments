import { Injectable } from '@angular/core';
import { Task } from '../models/task';

@Injectable({
  providedIn: 'root'
})
export class TaskService {
  tasks:Task[];
  constructor() { 
    this.tasks=[
      {taskId:101,taskName:"Learning",startDate:new Date("2020-02-10"),endDate:new Date("2020-03-26")},
      {taskId:102,taskName:"Dancing",startDate:new Date("2020-02-05"),endDate:new Date("2020-03-21")},
      {taskId:103,taskName:"Playing",startDate:new Date("2020-01-27"),endDate:new Date("2020-02-26")}
    ];
  }

  getAll():Task[]{
    return this.tasks;
  }

  get(Id:number){
    return this.tasks.find((t)=>(t.taskId==Id));
  }

  add(task1:Task){
    this.tasks.push(task1);
  }

  update(taskId:Task){
    let index=this.tasks.findIndex((t)=>(t.taskId===taskId.taskId));
    if(index>-1){
      this.tasks[index]=taskId;
    }
  }

  delete(Id:number){
    let index=this.tasks.findIndex((task)=>(task.taskId==Id));
    if(index>-1){
      this.tasks.splice(index,1);
    }
  }
}
