import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  private jobTitle:string=null;
  private salary:number=0;
  private annualSalary:number=0;
  public constructor(){
    this.jobTitle="Java Trainer";
    this.salary=50000;
  }
  public getAnnualSalary():number{
    this.annualSalary=this.salary*12;
    return this.annualSalary;
  }
}
