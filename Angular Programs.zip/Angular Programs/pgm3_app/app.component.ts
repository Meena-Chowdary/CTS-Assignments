import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 private userName:string=null;
 private logo:string=null;
 private salary:number=0;
 constructor(){
   this.salary=50000;
   this.logo="assets/download.jfif";
 }
 public getUser():void{
   this.userName="Ms. "+this.userName;
   alert("Hello "+this.userName);
 }
}
